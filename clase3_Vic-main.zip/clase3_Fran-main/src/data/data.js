const Data = [
    {
      id: '1',
      title: 'Pupusas',
      src: require('../img/pupusas-comida.jpg'),
    },
    {
      id: '2',
      title: 'Atol de Elote',
      src: require('../img/atol-bebida.jpg'),
    },
    {
      id: '3',
      title: 'Sopa de pata',
      src: require('../img/sopa-de-pata.jpg'),
    },
    {
      id: '4',
      title: 'Tamales de Elote',
      src: require('../img/tamales-comida.jpg'),
    }
  ];

  export default Data;


