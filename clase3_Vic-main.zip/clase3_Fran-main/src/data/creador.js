const creadorData = [
{
        id: '1',
        name: 'Wilfredo Granados',
        desc: `Ejemplo clase 3: Uso de un ReactNativePicker-Select y creación de un Stack de navegación en la aplicación`
}
  ];

  export default creadorData;
